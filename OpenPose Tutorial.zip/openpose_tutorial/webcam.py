
# -*- coding: utf-8 -*-

import os
import datetime
from pathlib import Path
from subprocess import Popen

root = Path().parent.absolute()
videos_dir = 'videos'
output_dir = 'output'
openpose_dir = 'openpose'

if not os.path.exists(output_dir):
    os.mkdir(output_dir)

t1 = datetime.datetime.now().time()
webcam_output = os.path.join(root, output_dir, str(t1.hour) + '_' + str(t1.minute) + '_' + str(t1.second))

if not os.path.exists(webcam_output):
    os.mkdir(webcam_output)

f = open("run.bat", 'w', encoding="utf-8")
content = 'cd {} \nbin\\OpenPoseDemo.exe --write_json {}'.format(openpose_dir, webcam_output)
f.write(content)
f.close()
p = Popen("run.bat")
p.wait()
    